package main;

/*
 * main  
 */

public class LibraryMain {

	public static void main(String[] args){
		new LoginJFrame();
	}
}
