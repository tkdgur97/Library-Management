create table book(
	number varchar(300) primary key,
	title varchar(300) unique key,
	author varchar(300),
	publisher varchar(300),
	year varchar(300),
	bill varchar(300),
	rent varchar(10)
);

create table members(
	id varchar(10) primary key not null,
	pw varchar(10) not null,
	name varchar(10),
	tel varchar(20),
	address varchar(50),
	bookrenturret varchar(1000),
	bookrentcumlative varchar(1000),
	booklate varchar(1000),
	rrn varchar(30) unique key
);

create table bookreturn(
	id varchar(10),
	title varchar(300),
	applyday varchar(50),
	foreign key(id) references members(id),
	foreign key(title) references book(title)
);

create table rent(
	id varchar(10),
	title varchar(300),
	rentday varchar(20),
	returnday varchar(20),
	extensionday varchar(10),
	returnCheck varchar(10),
	foreign key(id) references members(id),
	foreign key(title) references book(title)
);

create table reservation(
	id varchar(10),
	title varchar(300),
	date varchar(50),
	foreign key(id) references members(id),
	foreign key(title) references book(title)
);


